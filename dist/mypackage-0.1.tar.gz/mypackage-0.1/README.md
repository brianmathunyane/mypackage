# mypackage
I have created my first data science package: python package.

# installation

'pip install git + https://github.com/brianmathunyane/mypackage.git'
